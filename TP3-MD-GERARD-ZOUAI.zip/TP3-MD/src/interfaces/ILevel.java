package interfaces;

import model.Player;

public interface ILevel{
	
	public void initialiseLevel();
	public Player getPlayer();
	public boolean achievedGoal(Player p);
	 
}
