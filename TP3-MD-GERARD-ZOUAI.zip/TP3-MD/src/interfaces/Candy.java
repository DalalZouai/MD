package interfaces;

import java.awt.Color;
import java.awt.Graphics;

import model.CandyGrid;
import model.Colors;

public interface Candy {
	
	public Color getColor(Colors colors);
	public void setColor(int color);
	
	public int getNumColor();
	public void setNumColor(int numColor);
	
	public void draw(Graphics g, Colors colors, CandyGrid grid, int i, int j);
}
