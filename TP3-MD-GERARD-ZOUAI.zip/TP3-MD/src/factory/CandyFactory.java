package factory;

import java.util.Random;

import interfaces.Candy;
import interfaces.ILevel;
import model.Circle;
import model.Colors;
import model.Rectangle;
import model.Striped;

public class CandyFactory {
	public Candy createCandy(String candyType){		
		switch( candyType){
		case "circle":
			return new Circle();
		case "rectangle":
			return new Rectangle();
		case "stripedCircle":
			return new Striped(new Circle());
		case "stripedRectangle":
			return new Striped(new Rectangle());
			
		}
		return null;
	}
	
	public Candy createCandyLevel (ILevel level, Colors colors){
		Candy candy;
		Random rand = new Random();
		int test = 1 + rand.nextInt(100);
		 
		if ( test % 3 == 0 && ( level.getClass().getName().compareTo("levels.MiddleLevel") == 0 ) || (level.getClass().getName().compareTo("levels.HardLevel") == 0) ){
			candy = createCandy("stripedRectangle");
			candy.setColor(1 + rand.nextInt(colors.getColors().length - 1));
			return candy;
		}else if ( test % 2 == 0 && (level.getClass().getName().compareTo("levels.HardLevel") == 0) ){
			candy = createCandy("stripedCircle");
			candy.setColor(1 + rand.nextInt(colors.getColors().length - 1));
			return candy;
		} else if (test % 4 == 0 ) {
			candy = createCandy("circle");
			candy.setColor(1 + rand.nextInt(colors.getColors().length - 1));		
			return candy;

		} else {
			candy = createCandy("rectangle");
			candy.setColor(1 + rand.nextInt(colors.getColors().length - 1));
			return candy;
			
		}
	}
}
