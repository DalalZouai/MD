package factory;

import interfaces.ILevel;
import levels.EasyLevel;
import levels.HardLevel;
import levels.MiddleLevel;
import model.Player;

public class LevelFactory {
	
	int cpt = 1;
	public ILevel createLevel(String difficulty, Player player){		
		switch( difficulty){
		case "easy":
			return new EasyLevel(player, cpt);
		case "middle":
			return new MiddleLevel(player, cpt);
		case "hard":
			return new HardLevel(player, cpt);
			
		}
		return null;
	}
	
	public void setCompteur (int cpt){
		this.cpt = cpt+1;
	}
}
