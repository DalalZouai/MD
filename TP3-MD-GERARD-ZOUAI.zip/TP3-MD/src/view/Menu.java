package view;

import java.awt.Button;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import factory.LevelFactory;
import interfaces.ILevel;
import model.Player;

public class Menu extends WindowsView {
	private static JFrame frame = new JFrame();
	private ILevel state;
	private LevelFactory levelFact = new LevelFactory();
    private Player player;

	// initialisation : événements souris et boucle principale
	public Menu(ILevel state) {
		super(frame);
		this.state = state;
		initialiseMenu();
	}

	public Menu() {
		super(frame);
		initialiseMenu();
	}

	public void initialiseMenu() {    	
		Button b_niveaux = new Button("Niveaux");		
		
		b_niveaux.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				LevelsWindow niveaux = new LevelsWindow();
				frame.setContentPane(niveaux);
				frame.pack();
				frame.setVisible(true);			
			}
		});
		add(b_niveaux);

	}

	// boucle principale
	public void run() {
		while (true) {
			// un pas de simulation toutes les 100ms
			try {
				Thread.currentThread().sleep(100);
			} catch (InterruptedException e) {
			}

			// s'il n'y a pas de case vide, chercher des alignements
			// redessiner
		}
	}

	// met le jeu dans une fenêtre
	public static void main(String args[]) {

		// Trois boutons alignès

		frame.add(new Menu());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);

	}
}
