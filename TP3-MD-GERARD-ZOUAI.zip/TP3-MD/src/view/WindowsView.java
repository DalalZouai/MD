package view;

import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Panel;

import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowsView extends Panel{
		protected static Image buffer;
		
	    // coordonnées des cases sélectionnées : -1 = non sélectionné
	    int selectedX, selectedY; 
	    int swappedX, swappedY;
	    JButton button;
	    public static JFrame frame;

		
		public WindowsView(Image buffer, int selectedX, int selectedY, int swappedX, int swappedY, JFrame frame){
			this.buffer=buffer;
			this.selectedX = selectedX;
			this.selectedY = selectedY;
			this.swappedX = swappedX;
			this.swappedY = swappedY;
			this.button = new JButton("Jouer m");
			this.frame=frame;
		}
		
		public WindowsView(JFrame frame){
			this.frame = frame;
		}

		
		public WindowsView(){
			this.frame = frame;
		}
		
	    // évite le syntillements
	    public void update(Graphics g) {
	        paint(g);
	    }

	    // routine d'affichage : on fait du double buffering
	    public void paint(Graphics g2) {
	        if(buffer == null) buffer = createImage(1000, 800);
	        Graphics2D g = (Graphics2D) buffer.getGraphics();
	        
	        // fond
	        g.setColor(Color.WHITE);
	        g.fillRect(0, 0, getWidth(), getHeight());
	      
	        // copier l'image à l'écran
	        g2.drawImage(buffer, 0, 0, null);
	    }
	    

	    // taille de la fenêtre
	    public Dimension getPreferredSize() {
	        return new Dimension(32 * 8 + 1, 32 * 8 + 1);
	    }
	    
}
