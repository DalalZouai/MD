package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Panel;

import javax.swing.JFrame;

import controller.CandyGridController;
import interfaces.Candy;
import model.CandyGrid;
import model.Colors;

public class GameView extends Panel {
	// LLLL
	protected static Image buffer;

	// coordonnées des cases sélectionnées : -1 = non sélectionné
	int selectedX, selectedY;
	int swappedX, swappedY;
	protected static Colors colors;
	
	///
	CandyGridController gridC;
	/////
	protected static CandyGrid grid;
	
	int pointsMax;
	int coupsMax;

	private int nbCoups;
	private int nbPoints;

	private String name;

	public static JFrame frame;

	public GameView(Image buffer, int selectedX, int selectedY, int swappedX, int swappedY, CandyGrid grid, Colors colors,
			int pointsMax, int coupsMax) {
		this.buffer = buffer;
		this.selectedX = selectedX;
		this.selectedY = selectedY;
		this.swappedX = swappedX;
		this.swappedY = swappedY;
		this.colors = colors;
		this.grid = grid;
		this.pointsMax = pointsMax;
		this.coupsMax = coupsMax;
		this.frame = frame;

		//this.candy = new Circle(colors, );
	//	this.candyRect = new Rectangle(grid, colors);
	}

	// évite le syntillements
	public void update(Graphics g) {
		paint(g);
	}

	// routine d'affichage : on fait du double buffering
	public void paint(Graphics g2) {
		if (buffer == null)
			buffer = createImage(800, 600);
		Graphics2D g = (Graphics2D) buffer.getGraphics();

		// fond
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, getWidth(), getHeight());

		// afficher la grille vide
		g.setColor(Color.BLACK);
		for (int i = 0; i < 9; i++) {
			g.drawLine(32 * i, 0, 32 * i, 8 * 32 + 1);
			g.drawLine(0, 32 * i, 8 * 32 + 1, 32 * i);
		}

		// afficher la première case sélectionnée
		if (selectedX != -1 && selectedY != -1) {
			g.setColor(Color.ORANGE);
			g.fillRect(selectedX * 32 + 1, selectedY * 32 + 1, 31, 31);
		}

		// afficher la deuxième case sélectionnée
		if (swappedX != -1 && swappedY != -1) {
			g.setColor(Color.YELLOW);
			g.fillRect(swappedX * 32 + 1, swappedY * 32 + 1, 31, 31);
		}

		// afficher le contenu de la grille
		// for(int i = 0; i < 8; i++) {
		// for(int j = 0; j < 8; j++) {
		// if ( i < 4 || j > 6 ){
		//
		// candyRect.draw(g,i,j);
		// }else
		// candy.draw(g, i, j);
		// }
		// }
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				//g.setColor(colors.getColors(grid.getGrid(i, j).getNumColor()));
				grid.getGrid(i, j).draw(g, colors, grid, i, j);
				//g.fillOval(32 * i + 3, 32 * j + 3, 27, 27);
			}
		}

		// copier l'image à l'écran
		g2.drawImage(buffer, 0, 0, null);
		Font font = new Font("Arial", Font.BOLD, 15);
		g2.setFont(font);

		String objectif = "Objectif: " + pointsMax + "points";
		String coups = "Coups maximum: " + coupsMax;

		String points = "Points: " + nbPoints;
		String coupsJ = "Coups: " + nbCoups;

		String niveau = name;

		g2.drawString(name, (32 * 8 + 5), 30);

		g2.drawString(objectif, (32 * 8 + 5), 50);
		g2.drawString(coups, (32 * 8 + 5), 70);

		g2.drawString(points, (32 * 8 + 5), 90);
		g2.drawString(coupsJ, (32 * 8 + 5), 110);

	}

	public void recuperer_Score(int nbCoups, int nbPoints) {
		this.nbCoups = nbCoups;
		this.nbPoints = nbPoints;
	}

	public void recuperer_niveau(String name) {
		this.name = name;
	}

	// taille de la fenêtre
	public Dimension getPreferredSize() {
		return new Dimension(2 * (32 * 8 + 1), 32 * 8 + 1);
	}

}
