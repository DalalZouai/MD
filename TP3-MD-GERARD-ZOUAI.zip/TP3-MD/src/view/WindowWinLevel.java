package view;

import java.awt.Button;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import factory.LevelFactory;
import interfaces.ILevel;
import model.Player;

public class WindowWinLevel extends WindowsView {
	
		public static JFrame frame;
		private LevelFactory levelFact = new LevelFactory();
	    private Player player;
	    
	    
	    public Player getPlayer() {
			return player;
		}

		public void setPlayer(Player player) {
			this.player = player;
		}

		public WindowWinLevel() {
	    	frame = WindowsView.frame;
			initialiseNiveaux();
	    }
	    
		public void initialiseNiveaux() {    	
			Button niveauSuivant = new Button("Niveau suivant");
			Button menu = new Button("Menu");
			
			niveauSuivant.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					ILevel level;
					
					int cpt = player.getLevelList().size();
					levelFact.setCompteur(cpt);
					
					if (player.getNbEasyLevel() <= 5){
						
						level =  levelFact.createLevel("easy", player);
						frame.setContentPane((Container) level);

					}else if ( player.getNbEasyLevel() > 5){
						level =  levelFact.createLevel("middle", player);
						player = level.getPlayer();						
						frame.setContentPane((Container) level);
	
					}else if (player.getNbEasyLevel() > 5 && player.getNbMiddleLevel() > 10){
						level =  levelFact.createLevel("hard", player);
						player = level.getPlayer();
						frame.setContentPane((Container) level);
					}
					
					frame.pack();
					frame.setVisible(true);	
				}	
			});
			
				
			menu.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					Menu menu = new Menu();
					frame.setContentPane(menu);	
					frame.pack();
					frame.setVisible(true);
				}
			});
			
			add(niveauSuivant);
			add(menu);
		}

	    // boucle principale
	    public void run() {
	        while(true) {
	            // un pas de simulation toutes les 100ms
	            try { Thread.currentThread();
				Thread.sleep(100); } catch(InterruptedException e) { }
	            // redessiner
	        }
	    }
}
