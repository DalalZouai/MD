package view;

import java.awt.Button;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import factory.LevelFactory;
import interfaces.ILevel;
import model.Player;

public class LevelsWindow extends WindowsView{
	
		public static JFrame frame;
		private LevelFactory levelFact = new LevelFactory();
	    private Player player;
		private ILevel state;

	    
		// initialisation : événements souris et boucle principale
		public LevelsWindow(ILevel state) {
			super(frame);
			this.state = state;
			initialiseNiveaux();
		}

	    
	    public Player getPlayer() {
			return player;
		}

		public void setPlayer(Player player) {
			this.player = player;
		}

		public LevelsWindow() {
	    	frame = WindowsView.frame;
			initialiseNiveaux();
	    }
	    
		public void initialiseNiveaux() {    	
			Button niveau1 = new Button("Niveau facile");
			Button niveau2 = new Button("Niveau moyen");
			Button niveau3 = new Button("Niveau difficile");
			Button b_jouer = new Button("Reprendre la partie");
			Button menu = new Button("Menu");
			
			player = new Player();

			niveau1.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					ILevel level; 
					level =  levelFact.createLevel("easy", player);
					player = level.getPlayer();
					frame.setContentPane((Container) level);
					frame.pack();
					frame.setVisible(true);
				}
			});
			
			niveau2.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					ILevel level ; 
					level = levelFact.createLevel("middle", player);
					frame.setContentPane((Container) level);
					frame.pack();
					frame.setVisible(true);
				}
			});
			
			niveau3.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					ILevel level ; 
					level = levelFact.createLevel("hard", player);
					frame.setContentPane((Container) level);
					frame.pack();
					frame.setVisible(true);
				}
			});
			
			b_jouer.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {			
					if ( state != null){
						frame.setContentPane((Container) state);
						frame.pack();
						frame.setVisible(true);
					} else {
						ILevel level; 
						level =  levelFact.createLevel("easy", player);
						player = level.getPlayer();
						frame.setContentPane((Container) level);
						frame.pack();
						frame.setVisible(true); 
					}
				}
			});
				
			menu.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					Menu menu = new Menu();
					frame.setContentPane(menu);
					frame.pack();
					frame.setVisible(true);
				}
			});
			
			add(niveau1);
			add(niveau2);
			add(niveau3);
			add(b_jouer);
			add(menu);
		}

	    // boucle principale
	    public void run() {
	        while(true) {
	            // un pas de simulation toutes les 100ms
	            try { Thread.currentThread();
				Thread.sleep(100); } catch(InterruptedException e) { }
	            // redessiner
	        }
	    }
}
