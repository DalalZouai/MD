package levels;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Random;

import javax.swing.JFrame;

import controller.CandyGridController;
import controller.CareTaker;
import controller.Originator;
import interfaces.ILevel;
import model.CandyGrid;
import model.Colors;
import model.Player;
import view.GameView;
import view.LevelsWindow;
import view.Menu;
import view.WindowWinLevel;

public class HardLevel extends GameView implements Runnable, MouseListener, MouseMotionListener, ILevel {

	// grille avec un numéro de couleur par case
	static CandyGrid grid = new CandyGrid();

	// pour marquer les cases non alignées
	boolean marked[][] = new boolean[8][8];

	// couleur des cases : 0 = vide
	static Colors colors = new Colors();

	// Contrôleur de la grille
	CandyGridController gridControl = new CandyGridController(grid, colors, marked, this);

	// Frame
	static JFrame frame = new JFrame("Miam, des bonbons !");

	// Nombre de coups fait par le joueur.
	private int nbCoups;

	// Nombre de coups maximal.
	static Random rand = new Random();
	private static int nbCoupsMax =  8 + rand.nextInt(20 - 8);;

	// Nombre de points gagnés par le joueur.
	private static int nbPoints;

	// Nombre de points pour gagner la partie.
	private static int nbPointsMax =  500 + rand.nextInt(900 - 500);;

	// Gagner ou perdu
	private boolean win;
	
	private Player player;

	// coordonnées des cases sélectionnées : -1 = non sélectionné
	static int selectedX = -1;
	static int selectedY = -1;
	static int swappedX = -1;
	static int swappedY = -1;

	// image pour le rendu hors écran
	static Image buffer;

	public void initialiseLevel() {
		Button menu = new Button("Exit");
		BorderLayout layout = new BorderLayout();

		win = false;
		nbCoups = 0;
		nbPoints = 0;
		
		CareTaker caretaker = new CareTaker();
		Originator originator = new Originator();
		originator.set(this);
		caretaker.addMemento(originator.saveToMemento());
		originator.restoreFromMemento(caretaker.getMemento(0));

		menu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if ( originator.getState() != null )	{
					LevelsWindow menu = new LevelsWindow(originator.getState());
					frame.setContentPane(menu);
					frame.pack();
					frame.setVisible(true);
				}else{
					Menu menu = new Menu();
					frame.setContentPane(menu);
					frame.pack();
					frame.setVisible(true);
				}
			}
		});
		setLayout(layout);
		add(menu, BorderLayout.EAST);
	}

	// initialisation : événements souris et boucle principale
	public HardLevel(Player player, int cpt) {
		super(buffer, selectedX, selectedY, swappedX, swappedY, grid, colors, nbPointsMax, nbCoupsMax);
		frame = LevelsWindow.frame;
		this.player = player;
		
		String name = "Niveau difficile "+cpt;
		recuperer_niveau(name);
		
		initialiseLevel();

		// remplir une première fois la grille
		while (gridControl.fill())
			
		// enlever les alignements existants
		while (gridControl.removeAlignments()) {
			gridControl.fill();
		}
		addMouseListener(this);
		addMouseMotionListener(this);
		new Thread(this).start();
	}

	// gestion des événements souris
	public void mousePressed(MouseEvent e) {
		// on appuie sur le bouton de la souris : récupérer les coordonnées de
		// la première case
		selectedX = e.getX() / 32;
		selectedY = e.getY() / 32;
		repaint();

	}

	public void mouseMoved(MouseEvent e) {
		// on bouge la souris : récupérer les coordonnées de la deuxième case
		if (selectedX != -1 && selectedY != -1) {
			swappedX = e.getX() / 32;
			swappedY = e.getY() / 32;
			// si l'échange n'est pas valide, on cache la deuxième case
			if (!gridControl.isValidSwap(selectedX, selectedY, swappedX, swappedY)) {
				swappedX = swappedY = -1;
				repaint();
			}
		}
	}

	public void mouseReleased(MouseEvent e) {
		// lorsque l'on relâche la souris il faut faire l'échange et cacher les
		// cases
		if (selectedX != -1 && selectedY != -1 && swappedX != -1 && swappedY != -1) {
			gridControl.swap(selectedX, selectedY, swappedX, swappedY);

			// Augmente le nombre de tentative du joueur.
			nbCoups++;
			nbPoints = gridControl.getNbPointsTot();

		}
		selectedX = selectedY = swappedX = swappedY = -1;
		recuperer_Score(nbCoups, nbPoints);
		repaint();
	}

	// non implémentés
	public void mouseClicked(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mouseDragged(MouseEvent e) {
		mouseMoved(e);
	}

	// boucle principale
	public void run() {
		while (true) {
			// un pas de simulation toutes les 100ms
			try {
				Thread.currentThread().sleep(100);
			} catch (InterruptedException e) {
			}

			// s'il n'y a pas de case vide, chercher des alignements
			if (!gridControl.fill()) {
				gridControl.removeAlignments();
			}

			if (nbPoints >= nbPointsMax && nbCoups <= nbCoupsMax) {
				win();
				break;
			}
			if (nbCoups >= nbCoupsMax && nbPoints < nbPointsMax) {
				loose();
				break;
			}

			// redessiner
			repaint();
		}
	}

	public void win() {
		this.win = true;
		achievedGoal(player);
		
		WindowWinLevel wl = new WindowWinLevel();
		wl.setPlayer(player);
		
		frame.add(wl);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(wl);
		frame.pack();
		frame.setVisible(true);
	}

	public void loose() {
		achievedGoal(player);
		LevelsWindow niveau = new LevelsWindow();
		frame.add(niveau);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(niveau);
		frame.pack();
		frame.setVisible(true);
	}

	@Override
	public Player getPlayer() {
		return player;
	}

	@Override
	public boolean achievedGoal(Player p) {
		
		if(win){
		player.addLevelList(this);
		player.addCoups(nbCoups);
		player.addPoints(nbPoints);
		}	
		return win;	
	}

}
