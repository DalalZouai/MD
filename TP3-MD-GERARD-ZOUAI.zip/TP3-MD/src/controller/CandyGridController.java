package controller;

import factory.CandyFactory;
import interfaces.Candy;
import interfaces.ILevel;
import model.CandyGrid;
import model.Colors;
import model.Rectangle;

public class CandyGridController {

	private CandyGrid grid;
	private Colors colors;
	private boolean marked[][];
	private int nbPointsH = 0;
	private int nbPointsV = 0;
	private int nbPointsTot = 0;
	private CandyFactory candyFact = new CandyFactory();
	private ILevel level;

	public int getNbPointsTot() {
		this.nbPointsTot = nbPointsV + nbPointsH;

		return nbPointsTot;
	}

	public CandyGridController(CandyGrid grid, Colors colors, boolean marked[][], ILevel level) {

		this.nbPointsTot = 0;
		this.nbPointsV = 0;
		this.nbPointsH = 0;

		this.grid = grid;
		this.colors = colors;
		this.marked = marked;
		
		this.level=level;
	}

	public CandyGrid getGrid() {
		return grid;
	}

	public void setGrid(CandyGrid grid) {
		this.grid = grid;
	}

	public Colors getColors() {
		return colors;
	}

	public void setColors(Colors colors) {
		this.colors = colors;
	}

	public boolean[][] getMarked() {
		return marked;
	}

	public void setMarked(boolean[][] marked) {
		this.marked = marked;
	}

	// est-ce qu'on a trois cases de la même couleur vers le droite depuis (i,
	// j) ?
	boolean horizontalAligned(int i, int j) {
		if (i < 0 || j < 0 || i >= 6 || j >= 8)
			return false;
		if (grid.sameCandy(grid.getGrid(i, j), grid.getGrid(i + 1, j))
				&& grid.sameCandy(grid.getGrid(i, j), grid.getGrid(i + 2, j))) {
			return true;
		}
		return false;
	}

	// est-ce qu'on a trois cases de la même couleur vers le bas depuis (i, j) ?
	boolean verticalAligned(int i, int j) {

		if (i < 0 || j < 0 || i >= 8 || j >= 6) {
			return false;
		}
		if (grid.sameCandy(grid.getGrid(i, j), grid.getGrid(i, j + 1))
				&& grid.sameCandy(grid.getGrid(i, j), grid.getGrid(i, j + 2))) {
			return true;
		}
		return false;
	}

	// échanger le contenu de deux cases
	public void swap(int x1, int y1, int x2, int y2) {
		Candy tmp = grid.getGrid(x1, y1);
		grid.setGrid(x1, y1, x2, y2);
		grid.setGrid(x2, y2, tmp);
	}

	// détermine si l'échange entre deux cases est valide
	public boolean isValidSwap(int x1, int y1, int x2, int y2) {
		// il faut que les cases soient dans la grille
		if (x1 == -1 || x2 == -1 || y1 == -1 || y2 == -1)
			return false;

		// que les cases soient à côté l'une de l'autre
		if (Math.abs(x2 - x1) + Math.abs(y2 - y1) != 1)
			return false;

		// et que les couleurs soient différentes
		if (grid.sameCandy(grid.getGrid(x1, y1), grid.getGrid(x2, y2)))
			return false;

		// alors on effectue l'échange
		swap(x1, y1, x2, y2);

		// et on vérifie que ça créé un nouvel alignement
		boolean newAlignment = false;
		for (int i = 0; i < 3; i++) {
			newAlignment |= horizontalAligned(x1 - i, y1);
			newAlignment |= horizontalAligned(x2 - i, y2);
			newAlignment |= verticalAligned(x1, y1 - i);
			newAlignment |= verticalAligned(x2, y2 - i);
		}

		// puis on annule l'échange
		swap(x1, y1, x2, y2);
		return newAlignment;
	}

	// supprimer les alignements
	public boolean removeAlignments() {
		// passe 1 : marquer tous les alignements
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {

				if (grid.getGrid(i, j).getNumColor() != 0 && horizontalAligned(i, j)) {
					marked[i][j] = marked[i + 1][j] = marked[i + 2][j] = true;
					nbPointsH = nbPointsH + 30;
				}

				if (grid.getGrid(i, j).getNumColor() != 0 && verticalAligned(i, j)) {
					marked[i][j] = marked[i][j + 1] = marked[i][j + 2] = true;
					nbPointsV = nbPointsV + 40;
				}
			}
		}
		// passe 2 : supprimer les cases marquées
		boolean modified = false;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (marked[i][j]) {
					Candy circle2 = new Rectangle();
					circle2.setColor(0);
					grid.setGrid(i, j, circle2);
					marked[i][j] = false;
					modified = true;
				}
			}
		}
		return modified;
	}

	// remplir les cases vides par gravité, et générer des cases aléatoirement
	// par le haut
	public boolean fill() {
		boolean modified = false;
		for (int i = 0; i < 8; i++) {
			for (int j = 7; j >= 0; j--) {
				if (grid.getGrid(i, j).getNumColor() == 0) {
					
					if (j == 0) {
						grid.setGrid(i, j, candyFact.createCandyLevel(level, colors));
					} else {
						grid.setGrid(i, j, i, j - 1);
						Candy circle2 = new Rectangle();
						circle2.setColor(0);
						grid.setGrid(i, j - 1, circle2);
					}
					modified = true;
				}
			}
		}
		return modified;
	}
}
