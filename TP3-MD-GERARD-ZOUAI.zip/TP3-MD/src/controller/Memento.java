package controller;


import interfaces.ILevel;

public class Memento {
	
	private ILevel level;
	
	public Memento (ILevel level){
		this.level = level;
	}

	public ILevel getSavedState() {
		return level;
	}	
}
