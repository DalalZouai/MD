package controller;

import interfaces.ILevel;

public class Originator {
	
	 private ILevel state;
	   /* lots of memory consumptive private data that is not necessary to define the 
	    * state and should thus not be saved. Hence the small memento object. */

	   public void set(ILevel state) { 
	       this.state = state; 
	   }

	   public Memento saveToMemento() { 
	       return new Memento(state); 
	   }
	   public void restoreFromMemento(Memento m) {
	       state = m.getSavedState(); 
	   }

	public ILevel getState() {
		return state;
	}
	   

}
