package model;

import java.awt.Color;
import java.awt.Graphics;

import interfaces.Candy;

public class Rectangle implements Candy{
	
	private int numColor;


	public int getNumColor() {
		return numColor;
	}

	public void setNumColor(int numColor) {
		this.numColor = numColor;
	}

	public Color getColor(Colors colors) {
		return colors.getColors(numColor);
	}
	
	public void setColor(int color) {
		this.numColor = color;
	}


	@Override
	public void draw(Graphics g, Colors colors, CandyGrid grid, int i, int j) {

		g.setColor(getColor(colors));
		g.fillRect(32 * i + 5, 32 * j + 5, 24, 24);
	}
}
