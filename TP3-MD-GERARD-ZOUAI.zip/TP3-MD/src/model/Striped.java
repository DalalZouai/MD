package model;

import java.awt.Color;
import java.awt.Graphics;

import interfaces.Candy;

public class Striped extends Decoration{
	
	private int numColor;

    
	public Striped(Candy candy) {
		super(candy);
	}
	
	public void option(Graphics g,Colors colors, int i, int j){

	
		g.setColor(getColor(colors));
		//g.setXORMode(Color.BLACK);

		//g.fill3DRect(32 * i + 7, 32 * j + 7, 20, 20, false);
		g.fillRect(32 * i + 7, 32 * j + 7, 19, 19);

		g.setXORMode(Color.BLACK);
		
		
//		g.drawOval(32 * i + 7, 32 * j + 7, 20, 20);
		
	//g.drawLine(32 * i + 3, 32 * j + 3,32 * (i+1) , 32 * (j+1) );
		
//        g.fill3DRect(32 * i + 7, 32 * j + 7, 20, 20, true);
//		g.setColor(getColor(colors));
//		g.drawLine(32 * i + 3, 32 * j + 3,32 * (i+1) , 32 * (j+1) );
	
	}

	public int getNumColor() {
		return numColor;
	}

	public void setNumColor(int numColor) {
		this.numColor = numColor;
	}

	public Color getColor(Colors colors) {
		return colors.getColors(numColor);
	}
	
	public void setColor(int color) {
		this.numColor = color;
	}


	@Override
	public void draw(Graphics g, Colors colors, CandyGrid grid, int i, int j) {	
		candy.draw(g, colors, grid, i, j);
		option(g, colors, i, j);
	}

}
