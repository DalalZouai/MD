package model;

import java.util.Random;

import factory.CandyFactory;
import interfaces.Candy;

public class CandyGrid {
	
	
	private Candy[][] grid;
	private CandyFactory candyFact = new CandyFactory();

	public CandyGrid (){
		grid = new Candy[8][8];
		
		for ( int i = 0; i<8 ; i++){
			for (int j=0;j<8; j++){
				Random rand = new Random();
				if ( 1 + rand.nextInt(100) % 2 == 0)
					grid[i][j] = candyFact.createCandy("circle");
				else
					grid[i][j] = candyFact.createCandy("rectangle");

			}
		}
	}


	public Candy[][] getGrid() {
		return grid;
	}


	public void setGrid(Candy[][] grid) {
		this.grid = grid;
	}

	
	public Candy getGrid (int i, int j){
		return this.grid[i][j];
	}
	
	
	public void setGrid(int i, int j, int x, int y) {
		//this.grid[i][j] = grid[x][y];
		setGrid(i, j, getGrid(x,y));
	}
	
	
	public void setGrid(int i, int j, Candy grid2) {
		this.grid[i][j] = grid2;
	}

//	public void setGrid(int i, int j, int color) {
//		
//		this.grid[i][j].setColor(color);
//	}
	
	public boolean sameCandy (Candy candy, Candy candy2){
		// 

		if ( candy.getNumColor() == candy2.getNumColor()  && candy.getClass().getName().compareTo(candy2.getClass().getName()) == 0){
			return true;
		}
		return false;
	}
}
