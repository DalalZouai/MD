package model;

import java.awt.Graphics;

import interfaces.Candy;

public abstract class Decoration implements Candy{

	protected Candy candy;
	
	public Decoration (Candy candy){
		this.candy = candy;
	}
	
	@Override
	public void draw(Graphics g, Colors colors, CandyGrid grid, int i, int j) {
		candy.draw(g, colors, grid, i, j);
	}
	
	public abstract void option(Graphics g,Colors colors, int i, int j) ;
}
