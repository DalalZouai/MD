package model;
import java.awt.Color;

public class Colors {
	
	public Color colors[] = {Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.GRAY, Color.PINK, Color.CYAN};

	public Color[] getColors() {
		return colors;
	}
	
	public Color getColors(int i) {
		return colors[i];
	}

	public void setColors(Color[] colors) {
		this.colors = colors;
	}

}