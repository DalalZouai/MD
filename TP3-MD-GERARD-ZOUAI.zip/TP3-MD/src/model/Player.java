package model;

import java.util.LinkedList;

import interfaces.ILevel;
import levels.EasyLevel;
import levels.HardLevel;
import levels.MiddleLevel;

public class Player {
	
	private int nBcoups;
	private int points;
	private int nbPartiesWin;
	private int nbEasyLevel=0;
	private int nbMiddleLevel=0;
	private int nbHardLevel=0;
	private LinkedList<ILevel> levelList = new LinkedList<ILevel>();

	public int getNbEasyLevel() {
		nbEasyLevel = 0;
		for (ILevel level : levelList){
			if (level.getClass().getName().compareTo("levels.EasyLevel")== 0)
				nbEasyLevel+=1;
		}		
		return nbEasyLevel;
	}
	public int getNbMiddleLevel() {
		nbMiddleLevel = 0 ;
		for (ILevel level : levelList){
			if (level.getClass().getName().compareTo("levels.MiddleLevel")== 0)
				nbMiddleLevel+=1;
		}
		return nbMiddleLevel;
	}
	public int getNbHardLevel() {
		nbHardLevel = 0 ; 
		for (ILevel level : levelList){
			if (level.getClass().getName().compareTo("levels.HardLevel")== 0)
				nbHardLevel+=1;
		}
		return nbHardLevel;
	}	
	
	public int getnBcoups() {
		return nBcoups;
	}
	public void setnBcoups(int nBcoups) {
		this.nBcoups = nBcoups;
	}

	public LinkedList<ILevel> getLevelList() {
		return levelList;
	}
	public void setLevelList(LinkedList<ILevel> levelList) {
		this.levelList = levelList;
	}
	
	public void addLevelList(ILevel levelWin){
		if(levelWin.getClass().isInstance(EasyLevel.class)){
			nbEasyLevel +=1;
		}
		if(levelWin.getClass().isInstance(MiddleLevel.class)){
			nbMiddleLevel = 1;
		}
		if(levelWin.getClass().isInstance(HardLevel.class)){
			nbHardLevel +=1;
		}
		levelList.add(levelWin); 
	}
	


	public int getCoups() {
		return nBcoups;
	}
	public void setCoups(int coups) {
		this.nBcoups = coups;
	}
	public void addCoups(int coups){
		this.nBcoups += coups;
	}
	
	
	public void addPoints(int points){
		this.points += points;
	}
	
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	public int getNbPartiesWin() {
		return nbPartiesWin;
	}
	public void setNbPartiesWin() {
		this.nbPartiesWin = levelList.size();
	} 
}